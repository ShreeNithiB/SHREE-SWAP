'use client'

import { useState } from 'react'
import Image from 'next/image'
import { ArrowDownUp, ArrowRight, Check, ChevronDown, ExternalLink, Info, Menu, Plus, Settings, ShieldCheck, Wallet, X } from 'lucide-react'

const WOLF_IMAGE = '/images/shree-wolf.png'
const SOURCE_IMAGE = 'https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-kouiDVbVwM3ws2oTMxcnFqZn4Inh9K.png'

function NetworkBadge() {
  return <div className="network-badge"><span className="network-dot" /> Ethereum Sepolia <ChevronDown size={13} /></div>
}

function WalletButton({ connected, onClick }: { connected: boolean; onClick: () => void }) {
  return <button className="wallet-button" onClick={onClick}>{connected ? <><span className="wallet-dot" />0x7a...91f2</> : <><Wallet size={16} /> Connect wallet</>}</button>
}

function Header({ page, setPage }: { page: string; setPage: (page: string) => void }) {
  const [connected, setConnected] = useState(false)
  const [mobileOpen, setMobileOpen] = useState(false)
  return <header className="header"><div className="header-inner">
    <button className="brand" onClick={() => setPage('swap')}><span className="brand-mark"><Image src={WOLF_IMAGE} alt="Shree wolf logo" width={34} height={34} /></span><span>SHREE <em>SWAP</em></span></button>
    <nav className={mobileOpen ? 'nav mobile-visible' : 'nav'}>{['swap', 'liquidity', 'transactions'].map(item => <button key={item} className={page === item ? 'nav-link active' : 'nav-link'} onClick={() => { setPage(item); setMobileOpen(false) }}>{item[0].toUpperCase() + item.slice(1)}</button>)}</nav>
    <div className="header-actions"><NetworkBadge /><WalletButton connected={connected} onClick={() => setConnected(!connected)} /><button className="menu-button" aria-label="Toggle menu" onClick={() => setMobileOpen(!mobileOpen)}>{mobileOpen ? <X size={21} /> : <Menu size={21} />}</button></div>
  </div></header>
}

function TokenInput({ label, token, balance, value, onChange, disabled }: { label: string; token: string; balance: string; value?: string; onChange?: (v: string) => void; disabled?: boolean }) {
  return <div className="token-input"><div className="token-label"><span>{label}</span><span>Balance: {balance}</span></div><div className="token-row"><input aria-label={label} inputMode="decimal" placeholder="0.00" value={value} onChange={e => onChange?.(e.target.value)} disabled={disabled} /><button className="token-select"><Image src={token === 'SH' ? SOURCE_IMAGE : '/icon.svg'} alt="" width={25} height={25} />{token}<ChevronDown size={15} /></button></div></div>
}

function PoolStats() {
  return <section className="pool-overview"><div className="section-kicker">POOL OVERVIEW <span><span className="live-dot" /> Sepolia testnet</span></div><div className="pool-grid">{[['SH reserve', '--'], ['ETH reserve', '--'], ['Current price', '--'], ['24h volume', '--'], ['Liquidity', '--']].map(([label, value]) => <div className="pool-stat" key={label}><span>{label}</span><strong>{value}</strong></div>)}</div></section>
}

function SwapCard() {
  const [amount, setAmount] = useState('')
  const hasAmount = amount.trim().length > 0
  return <div className="swap-card"><div className="card-heading"><div><p className="eyebrow">SH / ETH</p><h1>Swap SH <span>↔</span> ETH</h1><p className="subheading">Trade SHREE tokens on Ethereum Sepolia</p></div><button className="icon-button" aria-label="Swap settings"><Settings size={18} /></button></div><div className="swap-fields"><TokenInput label="You pay" token="SH" balance="Connect wallet" value={amount} onChange={setAmount} /><button className="direction-button" aria-label="Reverse swap"><ArrowDownUp size={16} /></button><TokenInput label="You receive" token="ETH" balance="Connect wallet" disabled /></div><div className="trade-details"><div><span>Exchange rate</span><b>--</b></div><div><span>Minimum received</span><b>--</b></div><div><span>Price impact</span><b>--</b></div><div><span>LP fee</span><b>--</b></div><div className="route"><span>Route</span><b>SH <ArrowRight size={13} /> ETH</b></div></div><button className="primary-action">{!hasAmount ? 'Enter amount' : 'Approve SH'} <ArrowRight size={17} /></button><p className="wallet-note"><ShieldCheck size={14} /> Transactions are executed on Ethereum Sepolia</p></div>
}

function LiquidityPage() { return <main className="page-wrap"><div className="page-title"><p className="eyebrow">LIQUIDITY</p><h1>SH / ETH Liquidity Pool</h1><p>Provide liquidity and earn a share of trading fees.</p></div><div className="liquidity-layout"><div className="liquidity-card"><div className="card-heading"><div><p className="eyebrow">ADD LIQUIDITY</p><h2>Deposit assets</h2></div><button className="icon-button"><Info size={18} /></button></div><TokenInput label="SH amount" token="SH" balance="Connect wallet" /><TokenInput label="ETH amount" token="ETH" balance="Connect wallet" /><div className="deposit-summary"><div><span>Pool share</span><b>--</b></div><div><span>Current price</span><b>--</b></div></div><button className="primary-action">Approve SH <ArrowRight size={17} /></button></div><div className="pool-panel"><p className="eyebrow">YOUR POSITION</p><h2>Nothing deposited yet</h2><p>Connect your wallet to view your position and add liquidity to the SH / ETH pool.</p><button className="secondary-action">Connect wallet <Wallet size={16} /></button><div className="remove-box"><span>Remove liquidity</span><button disabled><Plus size={16} /> Manage position</button></div></div></div></main> }

function TransactionsPage() { return <main className="page-wrap"><div className="page-title"><p className="eyebrow">ACTIVITY</p><h1>Recent swaps</h1><p>Transactions from the SH / ETH pool on Ethereum Sepolia.</p></div><div className="transactions-card"><div className="empty-state"><div className="empty-icon"><ArrowDownUp size={20} /></div><h2>No transactions yet</h2><p>Swap activity will appear here once the pool is connected to a live contract.</p><button className="secondary-action">View Sepolia explorer <ExternalLink size={15} /></button></div></div></main> }

export default function Page() { const [page, setPage] = useState('swap'); return <><Header page={page} setPage={setPage} /><main className="app-shell">{page === 'swap' && <><section className="hero"><div className="hero-copy"><div className="hero-logo"><Image src={SOURCE_IMAGE} alt="Purple Shree wolf emblem" width={84} height={84} /></div><p className="eyebrow">DECENTRALIZED EXCHANGE</p><h2>A simpler way to <span>swap SHREE.</span></h2><p>Trade SH on Ethereum Sepolia with a transparent, non-custodial exchange.</p></div><SwapCard /></section><PoolStats /></>}{page === 'liquidity' && <LiquidityPage />}{page === 'transactions' && <TransactionsPage />}</main><footer><span>SHREE SWAP · Ethereum Sepolia</span><span>Built for the SHREE community</span></footer></> }
